package com.facebook.seleniumtests;

import java.time.Duration;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FacebookLoginTest {

    private WebDriver driver;

    @BeforeEach
    public void setUp() {
      
       
        // Initialize WebDriver
        driver = new ChromeDriver();
    }

    @Test
    public void testFacebookLogin() throws InterruptedException {
        // Navigate to Facebook
        driver.get("https://www.facebook.com");

        // Find the email input field and enter the test email address
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("userdemo1@gmail.com"); // Use your test account credentials
        
        Thread.sleep(5000);
        // Find the password input field and enter the test password
        WebElement passwordField = driver.findElement(By.id("pass"));
        passwordField.sendKeys("userdemo"); 
        
        Thread.sleep(5000);

        // Find the login button and click it
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

        // Wait for navigation and page load
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.titleContains("Facebook"));

        // Perform assertions to check if login was successful
        WebElement profileIcon = new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@aria-label='Account']")));

        Assertions.assertNotNull(profileIcon, "Profile icon should be present after successful login");
       
    }

    @AfterEach
    public void tearDown() {
        // Close the browser
    	driver.quit();
       
    }
}
