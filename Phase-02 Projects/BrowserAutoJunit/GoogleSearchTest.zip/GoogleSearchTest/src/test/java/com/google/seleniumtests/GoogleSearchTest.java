package com.google.seleniumtests;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.jupiter.api.Assertions;

public class GoogleSearchTest {
    private WebDriver driver;

    @BeforeEach
    public void setUp() {

        // Initialize WebDriver
        driver = new ChromeDriver();
    }

    @Test
    public void testGoogleSearch() throws InterruptedException {
        // Navigate to Google
        driver.get("http://www.google.com");

        // Find the search box and enter the search term
        WebElement searchBox = driver.findElement(By.name("q"));
        Thread.sleep(5000);
        searchBox.sendKeys("Selenium WebDriver");

        // Submit the search
        
        Thread.sleep(5000);
        searchBox.submit();

        // Wait for a second (just for demonstration)
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Check the title of the page
        
        Assertions.assertTrue(driver.getTitle().startsWith("Selenium WebDriver"));
        
        Thread.sleep(5000);
        WebElement link = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div[1]/div/div/span/a/div"));
        link.click();

        
    }


	@AfterEach
    public void tearDown() throws InterruptedException {
        // Close the browser
		Thread.sleep(100000);
        driver.quit();
    }
}
