package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class LoginSteps {

    private WebDriver driver;

    @Before
    public void setup() {
        // Set the path to the chromedriver executable
       

        // Initialize the ChromeDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Given("the employee is on the login page")
    public void employee_on_login_page() {
        // Navigate to the login page
        driver.get("http://www.amazon.in");
    }

    @When("the employee enters valid credentials")
    public void employee_enters_credentials() throws InterruptedException {
        // Find the username and password input fields
    	
    	Thread.sleep(10000);
    	 WebElement signInButton = driver.findElement(By.id("nav-link-accountList"));
         signInButton.click();

         // Wait for the next page to load
       
         Thread.sleep(10000);
         // Enter username
         WebElement usernameField = driver.findElement(By.id("ap_email"));
         usernameField.sendKeys("userdemo@gmail.com");

         Thread.sleep(10000);
         // Click continue
         WebElement continueButton = driver.findElement(By.id("continue"));
         continueButton.click();

         // Wait for the next page to load
         Thread.sleep(2000);

         // Enter password
         WebElement passwordField = driver.findElement(By.id("ap_password"));
         passwordField.sendKeys("user@123");

         Thread.sleep(10000);
         // Click sign-in
         WebElement signInSubmitButton = driver.findElement(By.id("signInSubmit"));
         signInSubmitButton.click();
         
         Thread.sleep(5000);
    }

   
    @Then("the employee should be redirected to the dashboard")
    public void employee_redirected_to_dashboard() throws InterruptedException {
        // Verify that the current URL is the dashboard
    	Thread.sleep(10000);
        assert driver.getCurrentUrl().equals("https://www.amazon.in/ref=nav_logo");
    }
    
    @When("the employee searches for {string}")
    public void the_employee_searches_for(String productName) throws InterruptedException {
        // Assuming there's a search bar we can locate by ID
    	Thread.sleep(10000);
        WebElement searchBar = driver.findElement(By.id("twotabsearchtextbox")); 
        searchBar.sendKeys(productName);
        searchBar.sendKeys(Keys.ENTER); 
    }
    @After
    public void teardown() throws InterruptedException {
        // Close the browser
    	
    	Thread.sleep(10000);
        if (driver != null) {
            driver.quit();
        }
    }
}
