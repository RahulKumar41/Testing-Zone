$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"cd8bafc9-d1d1-4495-8f89-4e68712e79fa","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1701499854534,"group":1,"content":"","tags":"","end":1701499893910,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});