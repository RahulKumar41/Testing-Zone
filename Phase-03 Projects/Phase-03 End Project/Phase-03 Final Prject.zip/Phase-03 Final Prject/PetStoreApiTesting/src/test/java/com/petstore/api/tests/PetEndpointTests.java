package com.petstore.api.tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import io.restassured.http.ContentType;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.hasKey;


public class PetEndpointTests {

    private static final int petId = 344; // This should be parameterized as needed

    @Test(priority = 1)
    public void createPet() {
        given()
            .contentType(ContentType.JSON)
            .body("{ \"id\": " + petId + ", \"name\": \"Doggie\", \"status\": \"available\" }")
        .when()
            .post("https://petstore.swagger.io/v2/pet")
        .then()
            .statusCode(200)
            .body("id", equalTo(petId))
            .body("name", equalTo("Doggie"))
            .body("status", equalTo("available"));
    }

    @Test(priority = 2, dependsOnMethods = {"createPet"})
    public void getPet() {
        given()
            .pathParam("petId", petId)
        .when()
            .get("https://petstore.swagger.io/v2/pet/{petId}")
        .then()
            .statusCode(200)
            .body("status", equalTo("available"));
        
        
    }
    
    @Test(priority = 3, dependsOnMethods = {"createPet", "getPet"})
    public void deletePet() {
        given()
            .contentType(ContentType.JSON)
            .pathParam("petId", petId)
        .when()
            .delete("https://petstore.swagger.io/v2/pet/{petId}")
        .then()
            .statusCode(200)
            .body("$", hasKey("code"))
            .body("$", hasKey("message"))
            .body("message", equalTo(String.valueOf(petId)));
    }
}
