package com.petstore.api.tests;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PetFindByStatusTests {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://petstore.swagger.io/v2";
    }

    @DataProvider(name = "statusProvider")
    public Object[][] provideStatus() {
        return new Object[][] {{"available"}, {"pending"}, {"sold"}};
    }

    @Test(dataProvider = "statusProvider")
    public void testFindByStatus(String status) {
        given()
            .queryParam("status", status)
        .when()
            .get("/pet/findByStatus")
        .then()
            .statusCode(200)
            .body("status", everyItem(is(status)));
    }
}
