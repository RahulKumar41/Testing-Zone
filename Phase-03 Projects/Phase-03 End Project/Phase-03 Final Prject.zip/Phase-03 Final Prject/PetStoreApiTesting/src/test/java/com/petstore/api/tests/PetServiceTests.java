package com.petstore.api.tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.util.HashMap;
import java.util.Map;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class PetServiceTests {

    private static Map<String, String> statusMap = new HashMap<>();

    @BeforeClass
    public void setUp() {
        // Set up base URI for REST Assured
        RestAssured.baseURI = "https://petstore.swagger.io/v2";

        // Set up environment-specific status values
        statusMap.put("DEV", "available_DEV");
        statusMap.put("QA", "available_QA");
        statusMap.put("PROD", "available_PROD");
    }

    @Test
    @Parameters("env")
    public void putCallTesting(String env) {
        // Get the status for the current environment
        String statusToUpdate = statusMap.get(env);

        // Perform the PUT request with the environment-specific status
        given()
            .contentType(ContentType.JSON)
            .body(createRequestBody(statusToUpdate))
        .when()
            .put("/pet")
        .then()
            .statusCode(200)
            .body("id", equalTo( 9223372016900013000L))
            .body("status", equalTo(statusToUpdate));
    }

    private String createRequestBody(String status) {
        // Create the JSON body with the dynamic status
        return "{ " +
            "\"id\": 9223372016900013000, " +
            "\"category\": { \"id\": 20021, \"name\": \"string\" }, " +
            "\"name\": \"doggie\", " +
            "\"photoUrls\": [ \"string\" ], " +
            "\"tags\": [ { \"id\": 0, \"name\": \"string\" } ], " +
            "\"status\": \"" + status + "\" " +
            "}";
    }
}
