package com.petstore.api.tests;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class UserDetailsValidationTests {

    @Test
    public void testUserDetails() {
        given()
            .when()
            .get("https://petstore.swagger.io/v2/user/user001")
            .then()
            .statusCode(200)
            .body("username", equalTo("user001"))
            .body("email", equalTo("Positive@Attitude.com"))
            .body("userStatus", equalTo(1));
    }

}
