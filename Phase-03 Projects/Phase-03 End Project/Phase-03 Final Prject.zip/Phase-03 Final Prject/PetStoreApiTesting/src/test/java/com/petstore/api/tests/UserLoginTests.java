package com.petstore.api.tests;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class UserLoginTests {

	
	@Test
	public void testUserLogin() {
	    given()
	        .auth()
	        .basic("User1", "Abby")
	        .when()
	        .get("https://petstore.swagger.io/v2/user/login")
	        .then()
	        .statusCode(200)
	        .body("code", equalTo(200))
	        .body("message", containsString("logged in user session"));
	}
}

