package com.petstore.api.tests;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UserLogoutTests {

    @Test
    public void testUserLogout() {
        given()
            .baseUri("https://petstore.swagger.io/v2")
        .when()
            .get("/user/logout")
        .then()
            .assertThat()
            .statusCode(200)
            .body("code", equalTo(200))
            .body("message", equalTo("ok"));
    }
}
