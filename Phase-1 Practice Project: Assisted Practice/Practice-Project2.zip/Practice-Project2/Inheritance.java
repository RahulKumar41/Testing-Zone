package AssistedPractice;

public class Inheritance {

	class A {
		public void methodA() {
			System.out.println("Base class method");
		}
	}

	class B extends A {
		public void methodB() {
			System.out.println("Child class method");
		}
	}

	public static void main(String args[]) {
		Inheritance outer = new Inheritance();
		B obj = outer.new B();
		obj.methodA(); //calling super class method
		obj.methodB(); //calling local method
	}
}
