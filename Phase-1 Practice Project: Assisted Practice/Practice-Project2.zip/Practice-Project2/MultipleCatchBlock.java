package io.com;

public class MultipleCatchBlock {

    public static void main(String[] args) {
        try {
            int a = 5 / 0; // This will result in an ArithmeticException
            System.out.println(a);
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic exception");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBounds exception");
        } catch (Exception e) {
            System.out.println("Parent exception");
        }
        System.out.println("rest of the code");
    }
}
