package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDropDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//1.Load the DB-Driver //It is mandatory
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				//2. Conect to the DB - use class DriverManager and method getConnection
			
				String dburl = "jdbc:mysql://localhost:3306/animated_movies";
				String username = "root";
				String password = "Rahul@123";
				
				String querry = "create database demo_database";
				String querry1 = "drop database demo_database";
				
				
				
				
				
				Connection con = DriverManager.getConnection(dburl, username, password);
				
				Statement stmt = con.createStatement();
				
				stmt.executeUpdate(querry1);
				
				System.out.println("Dtabse is droped successfully");
				
				
				
			
				

	}

}
