package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnectionTest {

    public static void main(String[] args) throws ClassNotFoundException {
    	
    	Class.forName("com.mysql.cj.jdbc.Driver");
        String jdbcUrl = null;
		try {
			jdbcUrl = "jdbc:mysql://localhost:3306/animated_movies";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Use your database URL
        String jdbcUser = "root";  // Use your database username
        String jdbcPassword = "Rahul@123";  // Use your database password

        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);
            if (connection != null) {
                System.out.println("Connected to the database!");
                connection.close();
            } else {
                System.out.println("Failed to make connection!");
            }
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}
