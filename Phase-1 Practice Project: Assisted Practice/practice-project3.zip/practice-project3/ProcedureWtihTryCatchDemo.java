package jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProcedureWtihTryCatchDemo {

	public static void main(String[] args) throws SQLException {
		
		//1.Load the DB-Driver //It is mandatory
				
				//2. Conect to the DB - use class DriverManager and method getConnection
			
				Connection con = null;
			
				String dburl = "jdbc:mysql://localhost:3306/animated_movies";
				String username = "root";
				String password = "Rahul@123";
				String query = "Call allmovies()";
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					
				
				
				con = DriverManager.getConnection(dburl, username, password);
				System.out.println("Successfully connected to Database");
				
				Statement stmt = con.createStatement();
				
				ResultSet rs = stmt.executeQuery(query);
				
			while(rs.next()) {
					
					System.out.println("Title: " + rs.getString("Title") + "\t");
					
					System.out.println("Genre: " + rs.getString("Genre") + "\t");
					
					System.out.println("Director: " + rs.getString("Director") + "\t");
					
					System.out.println("Release_year: " + rs.getString("Release_year") + "\t");
					
				}
			
				} catch(Exception e) {
					
					System.out.println(e.getMessage());
				}
				
				finally {
					con.close();
					
				}
				
				

	}

}
